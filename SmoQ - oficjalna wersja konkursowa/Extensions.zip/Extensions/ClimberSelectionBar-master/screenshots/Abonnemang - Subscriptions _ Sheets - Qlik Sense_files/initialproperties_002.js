/*global define*/
define( [], function () {
    'use strict';
    return {
        qHyperCubeDef: {
            qDimensions: [],
            qMeasures: [],
            qInitialDataFetch: [
                {
                    qWidth: 5,
                    qHeight: 50
                }
            ]
        }
    };
} );

# SenseUI-Slider
A simple Slider Range for multiple selections.

It uses jQuery UI and underscore. 

If you use it on your QMC just add the host into the whitelist

Added clickable ticks. It accepts only fields for now. The dimensions are causing selection issues. 

---

![SenseUI - Slider](/preview.png?raw=true "SenseUI - Slider")

![SenseUI - Slider - Settings](/screenshot1.png?raw=true "SenseUI - Slider Settings")

---

[Download zip file](https://github.com/yianni-ververis/SenseUI-Slider/archive/master.zip)

